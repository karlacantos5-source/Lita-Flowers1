Imágenes recortadas de la referencia visual proporcionada para usar en la maqueta Lita Flowers.
